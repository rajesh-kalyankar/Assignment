package main.assignment;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.logging.Logger;
import org.apache.commons.io.FileUtils;

public class TitleCaseProcessor
{
	private static final String FILE_EXTN = ".txt";
	private static final int THREAD_POOL_SIZE = 5;
	private static Logger logger = Logger.getLogger("MyLog");
	//private static String sourceDirPath = "C:\\logs\\Files\\";
	//private static String outputPath = "C:\\logs\\Files\\manipulated\\";
	private String sourceDirPath;
	private String className = "TitleCaseProcessor";
	
	public TitleCaseProcessor (String sourceDirPath)
	{
		this.sourceDirPath = sourceDirPath;
	}
	
	public void process() throws IOException
	{
		String methodName = "TitleCaseProcessor.process()";
		ExecutionTimeLogger timeLogger = new ExecutionTimeLogger(className, methodName,
		      logger);
		Stopwatch stopwatch = timeLogger.startLog();
		LoggerHandler.createLoggerHandler(logger);
		
		ExecutorService executor = Executors.newFixedThreadPool(THREAD_POOL_SIZE);
		File sourceFilePath = new File(sourceDirPath);
		
		isDirExists(sourceFilePath);
		
		Iterator<File> itr = FileUtils.iterateFiles(sourceFilePath, null, false);
		
		while (itr.hasNext())
		{
			File sourceFile = itr.next();
			
			if (!sourceFile.getName().trim().endsWith(FILE_EXTN))
			{
				continue;
			}
			
			logger.info("Input File Name " + sourceFile.getName());
			WorkerThread worker;
			
			try
			{
				InputStream inputStream = new FileInputStream(sourceFile);
				
				File outFile = new File(sourceDirPath + sourceFile.getName());
				worker = new WorkerThread(inputStream, outFile, logger);
				
				executor.execute(worker);
			}
			catch (Exception e)
			{
				logger.severe(e.getMessage());
			}
		}
		
		executor.shutdown();
		
		timeLogger.stopLog(stopwatch);
	}

	private void isDirExists(File sourceFilePath) throws IOException
	{
		if (!sourceFilePath.exists())
		{
			throw new IOException(
			      "Source directory is not exist!!! Please put proper directory path.");
		}
	}
}
