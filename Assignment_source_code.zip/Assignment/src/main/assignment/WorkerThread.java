package main.assignment;

import java.io.File;
import java.io.InputStream;
import java.util.logging.Logger;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;

public class WorkerThread implements Runnable
{
	private static final String SPACE_STRING = " ";
	private Logger logger;
	private InputStream inputStream;
	private File outFile;
	private static String className = "WorkerThread";

	public WorkerThread(InputStream in, File out, Logger logger)
	{
		this.inputStream = in;
		this.outFile = out;
		this.logger = logger;
	}

	@Override
	public void run()
	{
		execute();
	}

	private void execute()
   {
		String methodName = "execute";
		ExecutionTimeLogger timeLogger = new ExecutionTimeLogger(className, methodName,
		      logger);
		Stopwatch stopwatch = timeLogger.startLog();
		
		try
		{
			String output = toTitleCase(IOUtils.toString(inputStream));
			FileUtils.writeStringToFile(outFile, output);
			logger.info("written data into output file : " + outFile.getName());
		}
		catch (Exception e)
		{
			logger.severe(e.getMessage());
		}
		
		timeLogger.stopLog(stopwatch);
   }

	/**
	 *
	 * @param s is a string of any length
	 * @return a title cased string.
	 * All first letter of each word is made to uppercase
	 */
	public String toTitleCase(String s)
	{
		// check if the string is empty, if it is, return it immediately
		if (s.isEmpty())
		{
			return s;
		}

		// split string on space and create array of words
		String[] arr = s.split(SPACE_STRING);
		// create a string builder to hold the new capitalized string
		StringBuilder sb = new StringBuilder();
		// check if the array is empty (would be caused by the passage of s as an
		// empty string [i.g "" or " "],
		// if it is, return the original string immediately
		if (arr.length < 1)
		{
			return s;
		}

		for (int i = 0; i < arr.length; i++)
		{
			sb.append(Character.toUpperCase(arr[i].charAt(0))).append(arr[i].substring(1))
			      .append(SPACE_STRING);
		}
		
		return sb.toString().trim();
	}
	
}