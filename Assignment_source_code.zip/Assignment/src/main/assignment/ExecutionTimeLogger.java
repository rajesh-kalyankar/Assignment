package main.assignment;

import java.util.logging.Logger;

public class ExecutionTimeLogger
{
	private String methodName;
	private String className;
	private Logger logger;

	public ExecutionTimeLogger(String className, String methodName, Logger logger)
	{
		this.className = className;
		this.methodName = methodName;
		this.logger = logger;
	}

	public Stopwatch startLog()
	{
		Stopwatch executionTime = new Stopwatch();
		return executionTime;
	}

	public void stopLog(Stopwatch executionTime)
	{
		logger.info(" Exiting " + className + ": " + methodName + "()"
		      + " ====>> Time Taken by the method : [" + executionTime.elapsedTime()
		      + "]sec");
	}
}
