package main.assignment;

import java.io.File;
import java.io.IOException;
import java.util.logging.FileHandler;
import java.util.logging.SimpleFormatter;
import java.util.logging.Logger;

public class LoggerHandler
{
	public static void createLoggerHandler(Logger logger)
   {
	   FileHandler fileHandler = null;
		
		try
		{
			String loggerPath = System.getProperty("user.dir") + "\\assignment_log.log";
			
			File loggerFile = new File(loggerPath);

			if (!loggerFile.exists())
			{
				loggerFile.createNewFile();
			}
			
			fileHandler = new FileHandler(loggerPath);
			logger.addHandler(fileHandler);
			
			SimpleFormatter formatter = new SimpleFormatter();
			fileHandler.setFormatter(formatter);
			
			logger.info("Loggger file: " + loggerPath
			      + " is created for this assignment. Please check file for more details.");
		}
		catch (SecurityException e)
		{
			logger.severe(e.getMessage());
		}
		catch (IOException e)
		{
			logger.severe(e.getMessage());
		}
   }
}
