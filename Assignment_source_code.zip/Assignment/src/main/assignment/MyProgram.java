package main.assignment;

public class MyProgram
{
	public static void main(String[] args) throws Exception
	{
		if (args.length == 0 || args.length > 1)
		{
			throw new Exception(
			      "Please provide correct arguments.. First parameter is soruce directory path!!");
		}
		
		TitleCaseProcessor processor = new TitleCaseProcessor(args[0]);
		processor.process();
	}
}
