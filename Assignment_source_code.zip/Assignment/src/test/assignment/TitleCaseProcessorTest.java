package test.assignment;

import java.io.File;
import junit.framework.Assert;
import main.assignment.TitleCaseProcessor;
import org.apache.commons.io.FileUtils;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;

public class TitleCaseProcessorTest
{
	@Rule
   public TemporaryFolder tempFolder = new TemporaryFolder();
   
   @Test
   public void testProcess() throws Exception {
     // Create a temporary file.
    File tempFile = tempFolder.newFile("tempFile.txt");
   
     // Write something to it.
     FileUtils.writeStringToFile(tempFile, "hello world rajesh");
   
     // Read it from temp file
     final String s = FileUtils.readFileToString(tempFile);
   
     // Verify the content
     Assert.assertEquals("hello world rajesh", s);
     TitleCaseProcessor processor = new TitleCaseProcessor(tempFolder.getRoot().getAbsolutePath() + "\\");
     processor.process();
     
     
     Thread thread = new Thread();
     thread.start();
	  thread.sleep(500);
     //Read it from temp file
     final String s1 = FileUtils.readFileToString(tempFile);
   
     // Verify the content
     Assert.assertEquals("Hello World Rajesh", s1);
      
     //Note: File is guaranteed to be deleted after the test finishes.
   }
}
